# discord-joiner

a simple discord joiner by kek & yaboi

## Usage

First, install the dependencies:

```bash
pip install -r requirements.txt
```

Then, populate the `tokens.txt` file with your tokens.

Finally, run the script:

```bash
python main.py
```

![image](https://github.com/kekeds/discord-joiner/assets/107649934/c9fc3b9c-e5fa-4e98-9684-b77a6d2bfb8b)
